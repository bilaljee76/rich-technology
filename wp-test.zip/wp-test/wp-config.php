<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'rich' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '|dZu{yX>H#rNSgJt!4w8Z+CmX1uCWb>UtrJ;ZK+tg4H4NDTmHR@UA}bVM}y~Yjq5' );
define( 'SECURE_AUTH_KEY',  '{1{;<Y<iDO-DF%!AH(wvlrvY@-WQ48?;Hh^1K0;nCf*hXgKF|4e>Tr[7Eim}7s`V' );
define( 'LOGGED_IN_KEY',    '7$?o@fMz%>:$eBp+:(aj-7.!NVic@yTEUXH!PISk5`F;Uq*.PQAC&=Xsh16;G],m' );
define( 'NONCE_KEY',        '^v8Yy_shcqnjpy_Lnv%Ko(<RDbm~*S!1gp{QM8a>lnVz6ES(Yg6<_d4/(BYT[%b5' );
define( 'AUTH_SALT',        '!yV;s!,#AcPCD#Y]d5cvA~.3.wvGFn$B*TqqTCdc^a6*hFQ+ZcffIz$n^0~rkJLv' );
define( 'SECURE_AUTH_SALT', '>!)txov}M%n0`|+qQ,n[>BB?|~>oH:J%:~h4nyl`BInNQ`XK8i` c{}ZE;puCPg:' );
define( 'LOGGED_IN_SALT',   'iGDHntnj:+M~Vg$u_p7JUBlH&NL(7Vh6kktHOS)DHlKOn#Hf^j$]]ztGg^A<]Gq&' );
define( 'NONCE_SALT',       'FI}b9QJ%7Z|@0 YdtJ&7KvpE8SkY.B%LY+B&98 /G*xAUN<nkn+&%x@[0@xzW=gK' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

define('WP_MEMORY_LIMIT', '256M');


/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
