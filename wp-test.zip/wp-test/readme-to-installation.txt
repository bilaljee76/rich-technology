database rich.sql
availabe in main directory

create database with the name of 'rich'

Username: admin
Password bilalasghar7788


